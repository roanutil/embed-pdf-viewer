(function installAcroJs(globalObject) {
    const host = globalObject;
    const NativeDate = Date;
    let state = null;
    const cloneValue = (value) => Array.isArray(value) ? value.map((item) => String(item)) : value;
    const sameValue = (left, right) => {
        if (Array.isArray(left) && Array.isArray(right)) {
            return left.length === right.length && left.every((item, index) => item === right[index]);
        }
        return left === right;
    };
    const refKey = (ref) => {
        const value = ref;
        return value?.kind === 'objectNumber'
            ? `obj:${String(value.objectNumber)}`
            : `fqn:${String(value?.name ?? '')}`;
    };
    const diagnostic = (code, message) => {
        state?.diagnostics.push({ code, message });
    };
    const blocked = (api) => {
        diagnostic('blocked-network', `${api} is blocked by the scripting policy`);
        return undefined;
    };
    const numberValue = (value) => {
        if (typeof value === 'number')
            return Number.isFinite(value) ? value : 0;
        const parsed = Number(String(value ?? '').replace(/[^0-9+\-.]/g, ''));
        return Number.isFinite(parsed) ? parsed : 0;
    };
    const displayToCode = (display) => display === 'hidden' ? 1 : display === 'noPrint' ? 2 : display === 'noView' ? 3 : 0;
    const codeToDisplay = (code) => Number(code) === 1
        ? 'hidden'
        : Number(code) === 2
            ? 'noPrint'
            : Number(code) === 3
                ? 'noView'
                : 'visible';
    const eventName = (kind) => kind === 'widget-activate'
        ? 'Mouse Up'
        : kind === 'field-keystroke'
            ? 'Keystroke'
            : kind === 'field-validate'
                ? 'Validate'
                : kind === 'field-calculate'
                    ? 'Calculate'
                    : kind === 'field-format'
                        ? 'Format'
                        : 'Open';
    const doc = {};
    const makeField = (record) => {
        const input = record.input;
        const wrapper = {};
        Object.defineProperties(wrapper, {
            name: { enumerable: true, get: () => input.name },
            type: { enumerable: true, get: () => input.family },
            value: {
                enumerable: true,
                get: () => cloneValue(record.value),
                set: (value) => {
                    record.value = cloneValue(value);
                },
            },
            valueAsString: {
                enumerable: true,
                get: () => Array.isArray(record.value) ? record.value.join(',') : String(record.value ?? ''),
            },
            defaultValue: { enumerable: true, get: () => cloneValue(input.defaultValue) },
            readonly: {
                enumerable: true,
                get: () => Boolean(input.readOnly),
                set: () => {
                    diagnostic('unsupported-api', 'Field.readonly writes are not supported in v1');
                },
            },
            required: {
                enumerable: true,
                get: () => Boolean(input.required),
                set: () => {
                    diagnostic('unsupported-api', 'Field.required writes are not supported in v1');
                },
            },
            display: {
                enumerable: true,
                get: () => displayToCode(record.display),
                set: (value) => {
                    record.display = codeToDisplay(value);
                },
            },
            source: { enumerable: false, get: () => doc },
        });
        wrapper.setFocus = () => diagnostic('unsupported-api', 'Field.setFocus is not supported in v1');
        return wrapper;
    };
    const getField = (name) => state?.fieldsByName.get(String(name))?.wrapper ?? null;
    // ── the annots plane (curated; self-contained twins of src/color.ts and
    //    types.ts ANNOT_WRITABLE_KEYS — parity tests pin them) ───────────────
    const ANNOT_WRITABLE = {
        square: ['strokeColor', 'fillColor', 'opacity', 'width', 'borderStyle', 'dash', 'rect'],
        circle: ['strokeColor', 'fillColor', 'opacity', 'width', 'borderStyle', 'dash', 'rect'],
        polygon: ['strokeColor', 'fillColor', 'opacity', 'width', 'borderStyle', 'dash', 'rect'],
        polyline: ['strokeColor', 'fillColor', 'opacity', 'width', 'borderStyle', 'dash', 'rect'],
        line: ['strokeColor', 'fillColor', 'opacity', 'width', 'borderStyle', 'dash', 'rect'],
        ink: ['strokeColor', 'opacity', 'width', 'rect'],
        'free-text': ['strokeColor', 'fillColor', 'opacity', 'rect'],
        highlight: ['strokeColor', 'opacity'],
        underline: ['strokeColor', 'opacity'],
        squiggly: ['strokeColor', 'opacity'],
        strikeout: ['strokeColor', 'opacity'],
        caret: ['strokeColor', 'opacity'],
        text: ['strokeColor', 'opacity', 'rect'],
        stamp: ['rect'],
        'file-attachment': ['strokeColor', 'opacity'],
    };
    const ANNOT_FLAG_KEYS = ['hidden', 'print', 'readOnly', 'locked', 'noView', 'toggleNoView'];
    const ACROBAT_TYPE = {
        square: 'Square',
        circle: 'Circle',
        line: 'Line',
        polygon: 'Polygon',
        polyline: 'PolyLine',
        ink: 'Ink',
        'free-text': 'FreeText',
        highlight: 'Highlight',
        underline: 'Underline',
        squiggly: 'Squiggly',
        strikeout: 'StrikeOut',
        text: 'Text',
        stamp: 'Stamp',
        caret: 'Caret',
        'file-attachment': 'FileAttachment',
    };
    const isColorArray = (value) => {
        if (!Array.isArray(value) || value.length === 0)
            return false;
        const counts = { T: 0, G: 1, RGB: 3, CMYK: 4 };
        const expected = counts[String(value[0])];
        return (expected !== undefined &&
            value.length === expected + 1 &&
            value.slice(1).every((part) => typeof part === 'number' && isFinite(Number(part))));
    };
    const colorToRgbTriple = (value) => {
        const color = value;
        const space = String(color[0]);
        if (space === 'T')
            return null;
        if (space === 'G')
            return [Number(color[1]), Number(color[1]), Number(color[1])];
        if (space === 'RGB')
            return [Number(color[1]), Number(color[2]), Number(color[3])];
        const cyan = Number(color[1]);
        const magenta = Number(color[2]);
        const yellow = Number(color[3]);
        const black = Number(color[4]);
        return [
            1 - Math.min(1, cyan + black),
            1 - Math.min(1, magenta + black),
            1 - Math.min(1, yellow + black),
        ];
    };
    const sameAnnotValue = (left, right) => {
        if (Array.isArray(left) && Array.isArray(right)) {
            return left.length === right.length && left.every((item, index) => item === right[index]);
        }
        return left === right;
    };
    const cloneAnnotValue = (value) => (Array.isArray(value) ? [...value] : value);
    const makeAnnot = (record) => {
        const input = record.input;
        const subtype = String(input.subtype);
        const writable = ANNOT_WRITABLE[subtype] ?? [];
        const wrapper = {};
        const stage = (key, value, validate) => {
            // Flags and contents are writable on every script-addressable subtype;
            // appearance keys follow the per-subtype matrix.
            if (key !== 'contents' && ANNOT_FLAG_KEYS.indexOf(key) < 0 && writable.indexOf(key) < 0) {
                diagnostic('unsupported-api', `Annot.${key} is not writable on subtype '${subtype}' (write ignored)`);
                return;
            }
            if (input.opaqueBody && ANNOT_FLAG_KEYS.indexOf(key) < 0 && key !== 'contents') {
                diagnostic('unsupported-api', `Annot.${key}: '${subtype}' has an opaque appearance (write ignored)`);
                return;
            }
            if (!validate(value)) {
                diagnostic('invalid-field-value', `Annot.${key}: invalid value (write ignored)`);
                return;
            }
            record.current[key] = cloneAnnotValue(value);
        };
        const prop = (key, validate) => ({
            enumerable: true,
            get: () => cloneAnnotValue(record.current[key]),
            set: (value) => stage(key, value, validate),
        });
        const isNum = (value) => typeof value === 'number' && isFinite(value);
        const isBool = (value) => typeof value === 'boolean';
        Object.defineProperties(wrapper, {
            name: { enumerable: true, get: () => String(input.name ?? '') },
            type: { enumerable: true, get: () => ACROBAT_TYPE[subtype] ?? subtype },
            page: { enumerable: true, get: () => Number(input.page ?? 0) },
            author: { enumerable: true, get: () => String(input.author ?? '') },
            subject: { enumerable: true, get: () => String(input.subject ?? '') },
            strokeColor: prop('strokeColor', isColorArray),
            fillColor: prop('fillColor', isColorArray),
            opacity: prop('opacity', (value) => isNum(value) && Number(value) >= 0 && Number(value) <= 1),
            width: prop('width', (value) => isNum(value) && Number(value) >= 0),
            style: prop('borderStyle', (value) => value === 'S' || value === 'D'),
            dash: prop('dash', (value) => Array.isArray(value) && value.every(isNum)),
            rect: prop('rect', (value) => Array.isArray(value) && value.length === 4 && value.every(isNum)),
            contents: prop('contents', (value) => typeof value === 'string'),
            hidden: prop('hidden', isBool),
            print: prop('print', isBool),
            readOnly: prop('readOnly', isBool),
            lock: prop('locked', isBool),
            noView: prop('noView', isBool),
            toggleNoView: prop('toggleNoView', isBool),
            doc: { enumerable: false, get: () => doc },
        });
        wrapper.getProps = () => {
            const out = {};
            for (const key of Object.keys(record.current))
                out[key] = cloneAnnotValue(record.current[key]);
            return out;
        };
        wrapper.setProps = (props) => {
            const source = (props ?? {});
            for (const key of Object.keys(source)) {
                const alias = key === 'style' ? 'borderStyle' : key === 'lock' ? 'locked' : key;
                void alias;
                wrapper[key] = source[key];
            }
        };
        return wrapper;
    };
    const getAnnots = (spec) => {
        if (!state)
            return null;
        const nPage = spec?.nPage;
        if (nPage === undefined || nPage === null) {
            if (!state.annotsCoverDocument) {
                diagnostic('unsupported-api', 'getAnnots: whole-document search is limited to the prefetched pages (compatibility deviation)');
            }
            return state.annots.length ? state.annots.map((record) => record.wrapper) : null;
        }
        const page = Math.trunc(Number(nPage));
        if (!state.annotPages.has(page)) {
            diagnostic('unsupported-api', `getAnnots: page ${page} is outside the prefetched annots plane (compatibility deviation)`);
            return null;
        }
        const records = state.annotsByPage.get(page) ?? [];
        return records.length ? records.map((record) => record.wrapper) : null;
    };
    const getAnnot = (nPage, name) => {
        const records = getAnnots({ nPage });
        if (!records)
            return null;
        for (const wrapper of records) {
            if (String(wrapper.name) === String(name))
                return wrapper;
        }
        return null;
    };
    doc.getAnnots = getAnnots;
    doc.getAnnot = getAnnot;
    Object.defineProperties(doc, {
        documentFileName: {
            enumerable: true,
            get: () => String(state?.input.document?.fileName ?? ''),
        },
        numFields: { enumerable: true, get: () => state?.fields.length ?? 0 },
        pageNum: {
            enumerable: true,
            get: () => Number(state?.input.document?.pageNumber ?? 0),
            set: (value) => {
                const page = Math.trunc(Number(value));
                if (Number.isFinite(page))
                    state?.uiEffects.push({ kind: 'gotoPage', page });
            },
        },
    });
    doc.getField = getField;
    doc.getNthFieldName = (index) => String(state?.fields[Math.trunc(Number(index))]?.input.name ?? '');
    doc.resetForm = (names) => {
        if (!state)
            return;
        const requested = names === undefined
            ? state.fields
            : (Array.isArray(names) ? names : [names])
                .map((name) => state.fieldsByName.get(String(name)))
                .filter((field) => field !== undefined);
        for (const field of requested) {
            field.value = cloneValue(field.input.defaultValue);
            const key = refKey(field.input.ref);
            if (!state.resetKeys.has(key)) {
                state.resetKeys.add(key);
                state.resetRefs.push(field.input.ref);
            }
        }
    };
    doc.print = () => state?.uiEffects.push({ kind: 'print' });
    // Acrobat's doc.submitForm: positional (cURL, bFDF, bEmpty, aFields) or a
    // single argument object ({cURL, aFields, bEmpty, cSubmitAs, bGet}). It
    // emits a submit intent — resolution (Table 239/240 semantics) and the
    // sink chain (embedder handler → the document's home → blocked) live
    // outside the VM; nothing here touches a network.
    doc.submitForm = (cUrlOrArgs, bFDF, bEmpty, aFields) => {
        if (!state)
            return;
        const args = cUrlOrArgs !== null && typeof cUrlOrArgs === 'object'
            ? cUrlOrArgs
            : { cURL: cUrlOrArgs, bFDF, bEmpty, aFields };
        const names = Array.isArray(args.aFields)
            ? args.aFields.map((name) => String(name))
            : null;
        const submitAs = args.cSubmitAs === undefined ? undefined : String(args.cSubmitAs).toUpperCase();
        const format = submitAs === 'FDF'
            ? 'fdf'
            : submitAs === 'XFDF'
                ? 'xfdf'
                : submitAs === 'HTML'
                    ? 'html'
                    : submitAs === 'PDF'
                        ? 'pdf'
                        : args.bFDF === false
                            ? 'html'
                            : undefined;
        state.uiEffects.push({
            kind: 'submitForm',
            url: args.cURL === undefined || args.cURL === null ? null : String(args.cURL),
            fieldNames: names,
            includeEmpty: Boolean(args.bEmpty),
            ...(format === undefined ? {} : { format }),
            ...(args.bGet === undefined ? {} : { method: args.bGet ? 'get' : 'post' }),
        });
    };
    doc.mailDoc = () => blocked('mailDoc');
    doc.getURL = () => blocked('getURL');
    const app = {
        // Viewer identity — the properties Adobe's ubiquitous version-check
        // boilerplate (`!ADBE::…VersChk…` name-tree scripts) branches on. Honest
        // values for an emulated modern-Reader-level environment, so those
        // scripts take their "viewer is current" paths instead of tripping over
        // `undefined`. Deliberately no `xfa_installed`: we never claim XFA.
        platform: 'WIN',
        language: 'ENU',
        viewerType: 'Reader',
        viewerVariation: 'Reader',
        viewerVersion: 21,
        formsVersion: 21,
        alert: (message, icon, _type, title) => {
            state?.uiEffects.push({
                kind: 'alert',
                message: String(message),
                icon: Number.isFinite(Number(icon)) ? Number(icon) : 0,
                ...(title === undefined ? {} : { title: String(title) }),
            });
            return 1;
        },
        beep: () => diagnostic('unsupported-api', 'app.beep is not supported in v1'),
        response: () => {
            diagnostic('unsupported-api', 'app.response is not supported in v1');
            return null;
        },
        launchURL: () => blocked('app.launchURL'),
        // Acrobat's contract when a viewer component (e.g. the XFA plugin) is not
        // available is `undefined` — never a throw. A web viewer has no
        // installable components, so "not available" is always the truthful
        // answer; Adobe's XFA-check boilerplate calls this after its upgrade nag.
        findComponent: () => {
            diagnostic('unsupported-api', 'app.findComponent: no installable components in this viewer');
            return undefined;
        },
    };
    const pad = (value, length = 2) => String(value).padStart(length, '0');
    const monthShort = [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'May',
        'Jun',
        'Jul',
        'Aug',
        'Sep',
        'Oct',
        'Nov',
        'Dec',
    ];
    const monthLong = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December',
    ];
    const printd = (format, inputDate) => {
        const environment = (state?.input.environment ?? {});
        const date = inputDate && typeof inputDate.getTime === 'function'
            ? new NativeDate(Number(inputDate.getTime()))
            : new NativeDate(Number(environment.nowMs ?? 0));
        const local = new NativeDate(date.getTime() + Number(environment.utcOffsetMinutes ?? 0) * 60000);
        const year = local.getUTCFullYear();
        const month = local.getUTCMonth();
        const day = local.getUTCDate();
        const hour = local.getUTCHours();
        const minute = local.getUTCMinutes();
        const second = local.getUTCSeconds();
        const hour12 = hour % 12 === 0 ? 12 : hour % 12;
        const tokens = {
            yyyy: String(year),
            yy: pad(year % 100),
            mmmm: monthLong[month],
            mmm: monthShort[month],
            mm: pad(month + 1),
            m: String(month + 1),
            dd: pad(day),
            d: String(day),
            HH: pad(hour),
            hh: pad(hour12),
            h: String(hour12),
            H: String(hour),
            MM: pad(minute),
            M: String(minute),
            ss: pad(second),
            tt: hour < 12 ? 'am' : 'pm',
        };
        // Single pass, longest tokens first; replacements are never re-scanned, so
        // an emitted 'am'/'pm' cannot collide with the month token.
        return String(format).replace(/yyyy|mmmm|mmm|yy|mm|dd|HH|hh|MM|ss|tt|m|d|H|h|M/g, (token) => tokens[token]);
    };
    const util = {
        printd,
        printf: (format, ...values) => {
            let index = 0;
            return String(format).replace(/%(?:,?\d*(?:\.\d+)?)?[dfs]/g, (token) => {
                const value = values[index++];
                if (token.endsWith('s'))
                    return String(value ?? '');
                if (token.endsWith('d'))
                    return String(Math.trunc(numberValue(value)));
                const precision = /\.(\d+)/.exec(token)?.[1];
                return numberValue(value).toFixed(precision ? Number(precision) : 0);
            });
        },
    };
    const begin = (input, budget) => {
        const fields = (input.fields ?? []).map((field) => {
            const record = {
                input: field,
                originalValue: cloneValue(field.value),
                value: cloneValue(field.value),
                originalDisplay: String(field.display ?? 'visible'),
                display: String(field.display ?? 'visible'),
                wrapper: {},
            };
            record.wrapper = makeField(record);
            return record;
        });
        const fieldsByName = new Map(fields.map((field) => [String(field.input.name), field]));
        const fieldsByRef = new Map(fields.map((field) => [refKey(field.input.ref), field]));
        const annots = (input.annots ?? []).map((annotation) => {
            const writableSnapshot = () => ({
                strokeColor: cloneAnnotValue(annotation.strokeColor ?? ['T']),
                fillColor: cloneAnnotValue(annotation.fillColor ?? ['T']),
                opacity: Number(annotation.opacity ?? 1),
                width: Number(annotation.width ?? 1),
                borderStyle: String(annotation.borderStyle ?? 'S'),
                dash: cloneAnnotValue(annotation.dash ?? []),
                rect: cloneAnnotValue(annotation.rect ?? [0, 0, 0, 0]),
                contents: String(annotation.contents ?? ''),
                hidden: Boolean(annotation.hidden),
                print: Boolean(annotation.print),
                readOnly: Boolean(annotation.readOnly),
                locked: Boolean(annotation.locked),
                noView: Boolean(annotation.noView),
                toggleNoView: Boolean(annotation.toggleNoView),
            });
            const record = {
                input: annotation,
                original: writableSnapshot(),
                current: writableSnapshot(),
                wrapper: {},
            };
            record.wrapper = makeAnnot(record);
            return record;
        });
        const annotsByPage = new Map();
        for (const record of annots) {
            const page = Number(record.input.page ?? 0);
            const bucket = annotsByPage.get(page);
            if (bucket)
                bucket.push(record);
            else
                annotsByPage.set(page, [record]);
        }
        const eventInput = (input.event ?? {});
        const target = fieldsByRef.get(refKey(eventInput.target));
        const source = fieldsByRef.get(refKey(eventInput.source));
        const initialValue = eventInput.value !== undefined
            ? cloneValue(eventInput.value)
            : cloneValue(target?.value ?? null);
        const eventType = eventInput.type !== undefined
            ? String(eventInput.type)
            : eventInput.kind === 'name-tree-boot'
                ? 'Doc'
                : 'Field';
        const event = {
            // Explicit type/name (action-driven runs, from trigger provenance)
            // beat the kind-derived defaults (the K/V/C/F pipeline path).
            name: eventInput.name !== undefined
                ? String(eventInput.name)
                : eventName(String(eventInput.kind ?? '')),
            type: eventType,
            // Doc-typed events target the Doc object (Acrobat's WillSave
            // boilerplate does `event.target.getField(...)`); field targets win
            // when present (a widget-anchored run).
            target: target?.wrapper ?? (eventType === 'Doc' ? doc : null),
            targetName: String(target?.input.name ?? ''),
            source: source?.wrapper ?? { source: doc },
            value: initialValue,
            change: String(eventInput.change ?? ''),
            selStart: Math.max(0, Math.trunc(Number(eventInput.selStart ?? 0))),
            selEnd: Math.max(0, Math.trunc(Number(eventInput.selEnd ?? 0))),
            willCommit: Boolean(eventInput.willCommit),
            modifier: Boolean(eventInput.modifier),
            shift: Boolean(eventInput.shift),
            rc: true,
        };
        state = {
            input,
            fields,
            fieldsByName,
            fieldsByRef,
            annots,
            annotsByPage,
            annotPages: new Set((input.annotPages ?? []).map((page) => Math.trunc(Number(page)))),
            annotsCoverDocument: Boolean(input.annotsCoverDocument),
            event,
            resetRefs: [],
            resetKeys: new Set(),
            uiEffects: [],
            diagnostics: [],
            randomState: Number(input.environment?.randomSeed ?? 1) >>> 0,
            maxEffects: Math.max(1, Math.trunc(Number(budget?.maxEffects ?? 256))),
        };
        host.event = event;
        host.identity = { ...(input.identity ?? {}) };
    };
    const formValue = (field, value) => {
        const family = String(field.input.family);
        if (family === 'text')
            return { value: String(value ?? '') };
        if (family === 'checkbox' || family === 'radio') {
            // A toggle's script value is its export value, 'Off' when clear.
            return {
                value: value === null || value === undefined || String(value) === 'Off' ? null : String(value),
            };
        }
        if (family === 'combobox') {
            const selected = Array.isArray(value) ? value[0] : value;
            const text = selected === null || selected === undefined ? '' : String(selected);
            return { value: text === '' ? null : text };
        }
        if (family === 'listbox') {
            if (Array.isArray(value))
                return { selectedValues: value.map(String) };
            return {
                selectedValues: value === null || value === undefined || value === '' ? [] : [String(value)],
            };
        }
        diagnostic('invalid-field-value', `field '${String(field.input.name)}' cannot accept a scripted value`);
        return null;
    };
    const eventOutput = () => ({
        rc: Boolean(state?.event.rc),
        value: cloneValue(state?.event.value ?? null),
        change: String(state?.event.change ?? ''),
        selStart: Math.max(0, Math.trunc(Number(state?.event.selStart ?? 0))),
        selEnd: Math.max(0, Math.trunc(Number(state?.event.selEnd ?? 0))),
    });
    const finish = () => {
        if (!state)
            throw new Error('AcroJS run state was not initialized');
        const eventInput = state.input.event;
        const target = state.fieldsByRef.get(refKey(eventInput.target));
        const kind = String(eventInput.kind ?? '');
        if (target && kind === 'field-calculate')
            target.value = cloneValue(state.event.value);
        const formEffects = [];
        if (state.resetRefs.length > 0)
            formEffects.push({ kind: 'reset', refs: [...state.resetRefs] });
        for (const field of state.fields) {
            const key = refKey(field.input.ref);
            // A reset effect is replayed before the value effects below, so reset
            // fields start from their default rather than the transaction input.
            // This preserves reset -> rewrite-to-original sequences.
            const valueBaseline = state.resetKeys.has(key)
                ? field.input.defaultValue
                : field.originalValue;
            if (!sameValue(field.value, valueBaseline)) {
                const value = formValue(field, field.value);
                if (value)
                    formEffects.push({ kind: 'setValue', ref: field.input.ref, value });
            }
            if (field.display !== field.originalDisplay) {
                formEffects.push({ kind: 'setDisplay', ref: field.input.ref, display: field.display });
            }
        }
        if (target && kind === 'field-format') {
            formEffects.push({
                kind: 'setAppearanceText',
                ref: target.input.ref,
                text: String(state.event.value ?? ''),
            });
        }
        // Annot effects: the canonical per-annot diff, exactly the fields model —
        // last write wins per key, ordered by the input plane's annot order.
        const annotEffects = [];
        for (const record of state.annots) {
            const patch = {};
            const flags = {};
            for (const key of Object.keys(record.current)) {
                if (sameAnnotValue(record.current[key], record.original[key]))
                    continue;
                if (ANNOT_FLAG_KEYS.indexOf(key) >= 0)
                    flags[key] = record.current[key];
                else
                    patch[key] = cloneAnnotValue(record.current[key]);
            }
            if (Object.keys(flags).length > 0)
                patch.flags = flags;
            if (Object.keys(patch).length > 0)
                annotEffects.push({ ref: record.input.ref, patch });
        }
        const totalEffects = formEffects.length + annotEffects.length + state.uiEffects.length;
        if (totalEffects > state.maxEffects) {
            return {
                event: eventOutput(),
                formEffects: [],
                annotEffects: [],
                uiEffects: [],
                diagnostics: [...state.diagnostics],
                error: {
                    kind: 'budget',
                    message: `script produced ${totalEffects} effects; limit is ${state.maxEffects}`,
                },
            };
        }
        return {
            event: eventOutput(),
            formEffects,
            annotEffects,
            uiEffects: [...state.uiEffects],
            diagnostics: [...state.diagnostics],
        };
    };
    const failed = (error) => ({
        event: eventOutput(),
        formEffects: [],
        annotEffects: [],
        uiEffects: [],
        diagnostics: [...(state?.diagnostics ?? [])],
        error: {
            kind: 'exception',
            message: error instanceof Error ? error.message : String(error),
            ...(error instanceof Error && error.stack ? { stack: error.stack } : {}),
        },
    });
    const evaluate = (source) => {
        // Indirect eval is deliberate: name-tree declarations must persist in the
        // isolated realm's global scope for later field events.
        return (0, eval)(source);
    };
    const boot = (sources, input, budget) => {
        begin(input, budget);
        try {
            for (const source of sources ?? [])
                evaluate(String(source));
            return finish();
        }
        catch (error) {
            return failed(error);
        }
    };
    const run = (source, input, budget) => {
        begin(input, budget);
        try {
            evaluate(String(source));
            return finish();
        }
        catch (error) {
            return failed(error);
        }
    };
    // PDF scripts share this realm, but they must not replace the host-owned
    // transaction boundary for later events in the same document.
    Object.defineProperties(host, {
        __acrojsBoot: { configurable: false, writable: false, value: boot },
        __acrojsRun: { configurable: false, writable: false, value: run },
    });
    host.app = app;
    host.util = util;
    host.display = Object.freeze({ visible: 0, hidden: 1, noPrint: 2, noView: 3 });
    // The standard Acrobat color object: constants + convert/equal with the
    // documented G/RGB/CMYK vectors (self-contained twin of src/color.ts).
    host.color = Object.freeze({
        transparent: Object.freeze(['T']),
        black: Object.freeze(['G', 0]),
        white: Object.freeze(['G', 1]),
        gray: Object.freeze(['G', 0.5]),
        ltGray: Object.freeze(['G', 0.75]),
        dkGray: Object.freeze(['G', 0.25]),
        red: Object.freeze(['RGB', 1, 0, 0]),
        green: Object.freeze(['RGB', 0, 1, 0]),
        blue: Object.freeze(['RGB', 0, 0, 1]),
        cyan: Object.freeze(['CMYK', 1, 0, 0, 0]),
        magenta: Object.freeze(['CMYK', 0, 1, 0, 0]),
        yellow: Object.freeze(['CMYK', 0, 0, 1, 0]),
        convert: (value, space) => {
            if (!isColorArray(value))
                return ['T'];
            const target = String(space);
            const rgb = colorToRgbTriple(value);
            if (target === 'T' || rgb === null)
                return ['T'];
            if (target === 'G')
                return ['G', 0.3 * rgb[0] + 0.59 * rgb[1] + 0.11 * rgb[2]];
            if (target === 'RGB')
                return ['RGB', rgb[0], rgb[1], rgb[2]];
            if (target === 'CMYK') {
                const black = 1 - Math.max(rgb[0], rgb[1], rgb[2]);
                return ['CMYK', 1 - rgb[0] - black, 1 - rgb[1] - black, 1 - rgb[2] - black, black];
            }
            return ['T'];
        },
        equal: (left, right) => {
            if (!isColorArray(left) || !isColorArray(right))
                return false;
            const leftRgb = colorToRgbTriple(left);
            const rightRgb = colorToRgbTriple(right);
            if (leftRgb === null || rightRgb === null)
                return leftRgb === rightRgb;
            return leftRgb.every((component, index) => Math.abs(component - rightRgb[index]) < 1e-6);
        },
    });
    host.getField = getField;
    host.getAnnots = getAnnots;
    host.getAnnot = getAnnot;
    host.resetForm = doc.resetForm;
    host.print = doc.print;
    host.submitForm = doc.submitForm;
    host.mailDoc = doc.mailDoc;
    host.getURL = doc.getURL;
    Object.defineProperties(host, {
        documentFileName: { configurable: true, get: () => doc.documentFileName },
        numFields: { configurable: true, get: () => doc.numFields },
        pageNum: {
            configurable: true,
            get: () => doc.pageNum,
            set: (value) => {
                doc.pageNum = value;
            },
        },
    });
    class FixedDate extends NativeDate {
        constructor(...args) {
            if (args.length === 0) {
                super(Number((state?.input.environment ?? {}).nowMs ?? 0));
            }
            else if (args.length === 1) {
                super(args[0]);
            }
            else {
                super(Number(args[0]), Number(args[1]), Number(args[2] ?? 1), Number(args[3] ?? 0), Number(args[4] ?? 0), Number(args[5] ?? 0), Number(args[6] ?? 0));
            }
        }
        static now() {
            return Number((state?.input.environment ?? {}).nowMs ?? 0);
        }
    }
    host.Date = FixedDate;
    const math = host.Math;
    if (math) {
        math.random = () => {
            if (!state)
                return 0;
            state.randomState = (1664525 * state.randomState + 1013904223) >>> 0;
            return state.randomState / 0x100000000;
        };
    }
    host.AFSimple_Calculate = (operation, names) => {
        const requested = Array.isArray(names) ? names : String(names).split(',');
        const values = requested.map((name) => numberValue(getField(String(name).trim())?.value));
        const op = String(operation).toUpperCase();
        const value = values.length === 0
            ? 0
            : op === 'PRD'
                ? values.reduce((left, right) => left * right, 1)
                : op === 'AVG'
                    ? values.reduce((left, right) => left + right, 0) / values.length
                    : op === 'MIN'
                        ? Math.min(...values)
                        : op === 'MAX'
                            ? Math.max(...values)
                            : values.reduce((left, right) => left + right, 0);
        if (state)
            state.event.value = value;
    };
    host.AFNumber_Format = (decimals, separatorStyle, _negativeStyle, _currencyStyle, currency, prepend) => {
        if (!state)
            return;
        const places = Math.max(0, Math.min(10, Math.trunc(Number(decimals))));
        let formatted = numberValue(state.event.value).toFixed(places);
        if (Number(separatorStyle) === 0 || Number(separatorStyle) === 2) {
            const [whole, fraction] = formatted.split('.');
            formatted = `${whole.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}${fraction === undefined ? '' : `.${fraction}`}`;
        }
        const symbol = String(currency ?? '');
        state.event.value = prepend ? `${symbol}${formatted}` : `${formatted}${symbol}`;
    };
    host.AFPercent_Format = (decimals) => {
        if (!state)
            return;
        const places = Math.max(0, Math.min(10, Math.trunc(Number(decimals))));
        state.event.value = `${(numberValue(state.event.value) * 100).toFixed(places)}%`;
    };
    // ── Acrobat AF support library ─────────────────────────────────────────
    // Deterministic subset of Acrobat's AFxxx forms helpers. Everything reads
    // only the injected environment; keystroke helpers validate the committed
    // value (this pipeline runs K once, on commit, as a full replacement).
    const DATE_FORMATS = [
        'm/d',
        'm/d/yy',
        'mm/dd/yy',
        'mm/yy',
        'd-mmm',
        'd-mmm-yy',
        'dd-mmm-yy',
        'yy-mm-dd',
        'mmm-yy',
        'mmmm-yy',
        'mmm d, yyyy',
        'mmmm d, yyyy',
        'm/d/yy h:MM tt',
        'm/d/yy HH:MM',
    ];
    const TIME_FORMATS = ['HH:MM', 'h:MM tt', 'HH:MM:ss', 'h:MM:ss tt'];
    const rejectWithAlert = (message) => {
        if (!state)
            return;
        state.uiEffects.push({ kind: 'alert', message, icon: 0 });
        state.event.rc = false;
    };
    const formatMismatch = () => rejectWithAlert(`The value entered does not match the format of the field [ ${String(state?.event.targetName ?? '')} ]`);
    const dateMismatch = (format) => rejectWithAlert(`Invalid date/time: please ensure that the date/time exists. Field [ ${String(state?.event.targetName ?? '')} ] should match format ${String(format ?? '')}`);
    const mergeChange = (eventObject) => {
        const event = (eventObject ?? state?.event ?? {});
        const value = String(event.value ?? '');
        if (event.willCommit)
            return value;
        const start = Math.max(0, Math.trunc(Number(event.selStart ?? 0)));
        const end = Math.max(start, Math.trunc(Number(event.selEnd ?? 0)));
        return value.slice(0, start) + String(event.change ?? '') + value.slice(end);
    };
    host.AFMergeChange = mergeChange;
    const makeNumber = (value) => {
        if (typeof value === 'number')
            return Number.isFinite(value) ? value : null;
        let text = String(value ?? '').trim();
        if (text === '')
            return null;
        text = text.replace(/[^0-9,.\-+eE]/g, '');
        if (text.includes(',') && text.includes('.')) {
            // The last separator is the decimal: "1,234.56" vs "1.234,56".
            text =
                text.lastIndexOf(',') > text.lastIndexOf('.')
                    ? text.replace(/\./g, '').replace(',', '.')
                    : text.replace(/,/g, '');
        }
        else if (text.includes(',')) {
            // A single comma reads as the decimal separator; several are thousands.
            text =
                (text.match(/,/g) ?? []).length === 1 ? text.replace(',', '.') : text.replace(/,/g, '');
        }
        const parsed = Number(text);
        return text !== '' && Number.isFinite(parsed) ? parsed : null;
    };
    host.AFMakeNumber = makeNumber;
    host.AFExtractNums = (value) => {
        const matches = String(value ?? '').match(/\d+/g);
        return matches && matches.length > 0 ? [...matches] : null;
    };
    const validNumberText = (text, separatorStyle) => {
        const trimmed = text.trim();
        if (trimmed === '')
            return true;
        const decimalComma = separatorStyle === 2 || separatorStyle === 3;
        const pattern = decimalComma
            ? /^[+-]?(\d+|\d{1,3}(\.\d{3})+)?(,\d*)?$/
            : /^[+-]?(\d+|\d{1,3}(,\d{3})+)?(\.\d*)?$/;
        return pattern.test(trimmed) && /\d/.test(trimmed);
    };
    host.AFNumber_Keystroke = (_decimals, separatorStyle, _negativeStyle, _currencyStyle, currency) => {
        if (!state || !state.event.willCommit)
            return;
        const proposed = mergeChange(state.event);
        const cleaned = currency ? proposed.split(String(currency)).join('') : proposed;
        if (!validNumberText(cleaned, Math.trunc(Number(separatorStyle))))
            formatMismatch();
    };
    host.AFPercent_Keystroke = (_decimals, separatorStyle) => {
        if (!state || !state.event.willCommit)
            return;
        const cleaned = mergeChange(state.event).replace(/%\s*$/, '');
        if (!validNumberText(cleaned, Math.trunc(Number(separatorStyle))))
            formatMismatch();
    };
    const digitsOf = (value) => String(value ?? '').replace(/\D/g, '');
    const afSpecialFormat = (psf) => {
        if (!state)
            return;
        const digits = digitsOf(state.event.value);
        const kind = Math.trunc(Number(psf));
        let formatted = String(state.event.value ?? '');
        if (kind === 0)
            formatted = digits.slice(0, 5);
        else if (kind === 1)
            formatted = `${digits.slice(0, 5)}-${digits.slice(5, 9)}`;
        else if (kind === 2)
            formatted =
                digits.length >= 10
                    ? `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6, 10)}`
                    : `${digits.slice(0, 3)}-${digits.slice(3, 7)}`;
        else if (kind === 3)
            formatted = `${digits.slice(0, 3)}-${digits.slice(3, 5)}-${digits.slice(5, 9)}`;
        state.event.value = formatted;
    };
    host.AFSpecial_Format = afSpecialFormat;
    host.AFSpecial_Keystroke = (psf) => {
        if (!state || !state.event.willCommit)
            return;
        const merged = mergeChange(state.event);
        if (merged.trim() === '')
            return;
        const digits = digitsOf(merged).length;
        const kind = Math.trunc(Number(psf));
        const valid = kind === 0
            ? digits === 5
            : kind === 1
                ? digits === 9
                : kind === 2
                    ? digits === 7 || digits === 10
                    : digits === 9;
        if (!valid)
            formatMismatch();
    };
    host.AFRange_Validate = (useGreater, greaterThan, useLess, lessThan) => {
        if (!state)
            return;
        const value = makeNumber(state.event.value);
        if (value === null)
            return;
        const hasGreater = Boolean(useGreater);
        const hasLess = Boolean(useLess);
        const low = Number(greaterThan);
        const high = Number(lessThan);
        if ((!hasGreater || value >= low) && (!hasLess || value <= high))
            return;
        rejectWithAlert(hasGreater && hasLess
            ? `Invalid value: must be greater than or equal to ${low} and less than or equal to ${high}.`
            : hasGreater
                ? `Invalid value: must be greater than or equal to ${low}.`
                : `Invalid value: must be less than or equal to ${high}.`);
    };
    const nowWall = () => {
        const env = (state?.input.environment ?? {});
        const local = new NativeDate(Number(env.nowMs ?? 0) + Number(env.utcOffsetMinutes ?? 0) * 60000);
        return {
            y: local.getUTCFullYear(),
            m: local.getUTCMonth() + 1,
            d: local.getUTCDate(),
            H: 0,
            M: 0,
            S: 0,
        };
    };
    /** printd adds the environment offset itself, so a wall time converts back. */
    const wallDate = (parts) => {
        const env = (state?.input.environment ?? {});
        return new NativeDate(NativeDate.UTC(parts.y, parts.m - 1, parts.d, parts.H, parts.M, parts.S) -
            Number(env.utcOffsetMinutes ?? 0) * 60000);
    };
    /** Lenient scand-style parse: numbers mapped by the format's token order,
     *  month names accepted, missing parts defaulted like Acrobat's scand. */
    const parseDateLoose = (raw, format) => {
        const text = String(raw ?? '').trim();
        if (text === '')
            return null;
        const lower = text.toLowerCase();
        let namedMonth = null;
        for (let index = 0; index < 12; index += 1) {
            if (lower.indexOf(monthShort[index].toLowerCase()) >= 0) {
                namedMonth = index + 1;
                break;
            }
        }
        const timeMatch = /(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(am|pm)?/i.exec(text);
        let hours = 0;
        let minutes = 0;
        let seconds = 0;
        if (timeMatch) {
            hours = Number(timeMatch[1]);
            minutes = Number(timeMatch[2]);
            seconds = Number(timeMatch[3] ?? 0);
            const marker = String(timeMatch[4] ?? '').toLowerCase();
            if (marker === 'pm' && hours < 12)
                hours += 12;
            if (marker === 'am' && hours === 12)
                hours = 0;
            if (hours > 23 || minutes > 59 || seconds > 59)
                return null;
        }
        const dateText = timeMatch
            ? text.slice(0, timeMatch.index) + text.slice(timeMatch.index + timeMatch[0].length)
            : text;
        const numbers = (dateText.match(/\d+/g) ?? []).map((token) => Number(token));
        const order = [];
        for (const token of String(format ?? '').match(/yyyy|mmmm|mmm|yy|mm|dd|m|d/g) ?? []) {
            const kind = (token[0] === 'y' ? 'y' : token[0] === 'm' ? 'm' : 'd');
            if (order.indexOf(kind) < 0)
                order.push(kind);
        }
        let year = null;
        let month = namedMonth;
        let day = null;
        let cursor = 0;
        for (const kind of order) {
            if (kind === 'm' && namedMonth !== null)
                continue;
            if (cursor >= numbers.length)
                break;
            const value = numbers[cursor];
            cursor += 1;
            if (kind === 'y')
                year = value;
            else if (kind === 'm')
                month = value;
            else
                day = value;
        }
        if (year === null && month === null && day === null && !timeMatch)
            return null;
        const today = nowWall();
        if (year === null)
            year = today.y;
        else if (year < 100)
            year = year < 50 ? 2000 + year : 1900 + year;
        if (month === null)
            month = today.m;
        if (day === null)
            day = 1;
        if (month < 1 || month > 12 || day < 1 || day > 31)
            return null;
        const probe = new NativeDate(NativeDate.UTC(year, month - 1, day));
        if (probe.getUTCFullYear() !== year ||
            probe.getUTCMonth() !== month - 1 ||
            probe.getUTCDate() !== day) {
            return null;
        }
        return { y: year, m: month, d: day, H: hours, M: minutes, S: seconds };
    };
    const afDateFormatEx = (format) => {
        if (!state)
            return;
        const raw = String(state.event.value ?? '');
        if (raw.trim() === '')
            return;
        let date = new FixedDate(raw);
        if (Number.isNaN(date.getTime())) {
            const parts = parseDateLoose(raw, format);
            if (!parts)
                return; // unparsable: leave the value untouched
            date = wallDate(parts);
        }
        state.event.value = printd(format, date);
    };
    host.AFDate_FormatEx = afDateFormatEx;
    host.AFDate_Format = (index) => afDateFormatEx(DATE_FORMATS[Math.trunc(Number(index))] ?? 'm/d/yy');
    const afDateKeystrokeEx = (format) => {
        if (!state || !state.event.willCommit)
            return;
        const merged = mergeChange(state.event);
        if (merged.trim() === '')
            return;
        if (!parseDateLoose(merged, format))
            dateMismatch(format);
    };
    host.AFDate_KeystrokeEx = afDateKeystrokeEx;
    host.AFDate_Keystroke = (index) => afDateKeystrokeEx(DATE_FORMATS[Math.trunc(Number(index))] ?? 'm/d/yy');
    const afTimeFormatEx = (format) => {
        if (!state)
            return;
        const raw = String(state.event.value ?? '');
        if (raw.trim() === '')
            return;
        const parts = parseDateLoose(raw, format);
        if (!parts)
            return;
        state.event.value = printd(format, wallDate(parts));
    };
    host.AFTime_FormatEx = afTimeFormatEx;
    host.AFTime_Format = (index) => afTimeFormatEx(TIME_FORMATS[Math.trunc(Number(index))] ?? 'HH:MM');
    host.AFTime_Keystroke = (index) => {
        if (!state || !state.event.willCommit)
            return;
        const merged = mergeChange(state.event);
        if (merged.trim() === '')
            return;
        if (!parseDateLoose(merged, TIME_FORMATS[Math.trunc(Number(index))] ?? 'HH:MM')) {
            dateMismatch(TIME_FORMATS[Math.trunc(Number(index))] ?? 'HH:MM');
        }
    };
    // QuickJS does not provide browser networking, but explicitly shadow these
    // names so a future adapter cannot accidentally inject ambient authority.
    host.fetch = undefined;
    host.XMLHttpRequest = undefined;
    host.WebSocket = undefined;
})(globalThis);